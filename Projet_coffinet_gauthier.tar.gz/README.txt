﻿################################
#             Étudiant du Groupe               #
################################
Dorian Coffinet
Thibault Gauthier


################################
#  Environnement de développement  #
################################
Java 7




################################
#                       Manuel                         #
################################


Lancement de l’interface avec java -jar id3.jar


L’interface permet de choisir un fichier au format arff via le bouton “File”.


Dans le panel de gauche il est possible de choisir les options pour la construction de l’arbre de décision :
        - Rate : Pour choisir le taux d’erreur maximum
        - Deap : pour choisir la profondeur maximal de l’arbre


Le bouton “Compute” en bas à gauche lance l’algorithme et affiche les résultats dans le panel droit de l’interface